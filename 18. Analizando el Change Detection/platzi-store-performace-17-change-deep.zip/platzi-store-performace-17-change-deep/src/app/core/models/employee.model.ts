export interface EmployeeData {
  label: string;
  num: number;
}
