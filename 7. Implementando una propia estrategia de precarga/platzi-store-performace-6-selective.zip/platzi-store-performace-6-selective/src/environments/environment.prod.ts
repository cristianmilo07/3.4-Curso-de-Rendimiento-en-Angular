export const environment = {
  production: true,
  url_api: 'https://platzi-store.herokuapp.com',
  firebase: {
    apiKey: 'AIzaSyDYrnAORATRygACacyOwg1GdGidn8wRyJw',
    authDomain: 'platzi-store-f4261.firebaseapp.com',
    databaseURL: 'https://platzi-store-f4261.firebaseio.com',
    projectId: 'platzi-store-f4261',
    storageBucket: 'platzi-store-f4261.appspot.com',
    messagingSenderId: '726188212196',
    appId: '1:726188212196:web:a0b4e737ec563410'
  }
};
